using System.Collections; // Importa a biblioteca para trabalhar com coleções genéricas (não utilizada diretamente neste código, mas pode ser útil em outros casos).
using System.Collections.Generic; // Importa a biblioteca para trabalhar com listas e coleções genéricas (também não usada diretamente aqui).
using UnityEngine; // Importa a biblioteca do Unity, que contém as funções e classes principais para trabalhar com o motor gráfico.

public class AtivadorDeInimigos : MonoBehaviour // Definição da classe 'AtivadorDeInimigos' que herda de MonoBehaviour, para ser um componente de GameObject no Unity.
{
    void OnTriggerEnter2D(Collider2D other) // Função chamada automaticamente quando um objeto colide com o collider 2D deste objeto.
    {
        if(other.gameObject.CompareTag("Inimigo")) // Verifica se o objeto que entrou em contato com o collider tem a tag "Inimigo".
        {
            other.gameObject.GetComponent<Inimigos>().AtivarInimigo(); // Se o objeto for um inimigo, chama o método 'AtivarInimigo' do componente 'Inimigos' associado ao objeto.
        }
    }
}
