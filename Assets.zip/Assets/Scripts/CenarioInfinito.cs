using System.Collections; // Importa a biblioteca para trabalhar com coleções genéricas (não utilizada diretamente neste código, mas pode ser útil em outros casos).
using System.Collections.Generic; // Importa a biblioteca para trabalhar com listas e coleções genéricas (também não usada diretamente aqui).
using UnityEngine; // Importa a biblioteca do Unity, que contém as funções e classes principais para trabalhar com o motor gráfico.

public class CenarioInfinito : MonoBehaviour // Define a classe 'CenarioInfinito', que herda de MonoBehaviour, para ser um componente do Unity.
{
    public float velocidadeDoCenario; // Declara uma variável pública que controla a velocidade do movimento do cenário. O valor pode ser ajustado na interface do Unity.

    // Update is called once per frame
    void Update() 
    {
        MovimentarCenario(); // Chama a função 'MovimentarCenario' a cada frame para mover o cenário.
    }

    private void MovimentarCenario() 
    {
        // Cria um vetor 2D que define o deslocamento do cenário. A coordenada x é calculada com base no tempo (Time.time) multiplicado pela velocidade do cenário.
        Vector2 deslocamentoDoCenario = new Vector2(Time.time * velocidadeDoCenario, 0f);
        
        // A propriedade 'mainTextureOffset' ajusta a posição da textura do material do objeto, criando o efeito de movimento infinito.
        // 'GetComponent<Renderer>()' obtém o componente Renderer do objeto, que é responsável pela renderização do objeto no jogo.
        // 'material.mainTextureOffset' ajusta o deslocamento da textura no eixo X.
        GetComponent<Renderer>().material.mainTextureOffset = deslocamentoDoCenario;
    }
}

