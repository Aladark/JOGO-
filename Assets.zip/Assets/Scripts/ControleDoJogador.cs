using System.Collections; // Importa a biblioteca para trabalhar com coleções genéricas (não usada diretamente neste código, mas pode ser útil em outros casos).
using System.Collections.Generic; // Importa a biblioteca para trabalhar com listas e coleções genéricas (também não usada diretamente aqui).
using UnityEngine; // Importa a biblioteca do Unity, que contém as funções e classes principais para trabalhar com o motor gráfico.

public class ControleDoJogador : MonoBehaviour // Define a classe 'ControleDoJogador', que herda de MonoBehaviour, para ser um componente de GameObject no Unity.
{
    // Declaração de variáveis públicas que podem ser ajustadas no editor do Unity:
    public Rigidbody2D oRigidbody2D; // Referência para o Rigidbody2D do jogador, usado para manipular a física e o movimento.
    public GameObject laserDoJogador; // Prefab do laser disparado pelo jogador.
    public Transform localDoDisparoUnico; // Localização do disparo único do laser.
    public Transform localDoDisparoDaEsquerda; // Localização do disparo do laser à esquerda.
    public Transform localDoDisparoDaDireita; // Localização do disparo do laser à direita.
    public float tempoMaximoDosLasersDuplos; // Tempo máximo que o laser duplo ficará ativo.
    public float tempoAtualDosLasersDuplos; // Tempo atual dos lasers duplos (contagem regressiva).

    public float velocidadeDaNave; // Velocidade de movimentação do jogador.

    public bool temLaserDuplo; // Variável que indica se o jogador tem o laser duplo ativo.
    public bool jogadorEstaVivo; // Variável que indica se o jogador está vivo.

    private Vector2 teclasApertadas; // Armazena o valor das teclas pressionadas para mover o jogador.

    // Start é chamado antes da primeira atualização de quadro.
    void Start()
    {
        temLaserDuplo = false; // Inicializa a variável que indica se o jogador tem o laser duplo.
        jogadorEstaVivo = true; // Inicializa a variável que indica se o jogador está vivo.

        tempoAtualDosLasersDuplos = tempoMaximoDosLasersDuplos; // Define o tempo inicial do laser duplo.
    }

    // Update é chamado uma vez por quadro.
    void Update()
    {
        MovimentarJogador(); // Chama a função para mover o jogador.

        // Verifica se o jogador está vivo antes de permitir o disparo de laser.
        if(jogadorEstaVivo == true)
        {
            AtirarLaser(); // Chama a função para disparar o laser se o jogador estiver vivo.
        }

        // Verifica se o jogador tem laser duplo ativo.
        if(temLaserDuplo == true)
        {
            tempoAtualDosLasersDuplos -= Time.deltaTime; // Reduz o tempo do laser duplo com base no tempo passado.

            // Se o tempo dos lasers duplos acabar, desativa o laser duplo.
            if(tempoAtualDosLasersDuplos <= 0)
            {
                DesativarLaserDuplo(); // Desativa o laser duplo.
            }
        }
    }

    // Função para movimentar o jogador com base nas teclas pressionadas.
    private void MovimentarJogador()
    {
        // Armazena as entradas de movimentação do jogador.
        teclasApertadas = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        
        // Aplica a velocidade da nave ao Rigidbody2D para mover o jogador.
        oRigidbody2D.velocity = teclasApertadas.normalized * velocidadeDaNave;
    }

    // Função para disparar o laser.
    private void AtirarLaser()
    {
        // Verifica se o jogador apertou o botão de disparo.
        if(Input.GetButtonDown("Fire1"))
        {
            // Se o jogador não tem o laser duplo, dispara um laser simples.
            if(temLaserDuplo == false)
            {
                // Instancia o laser no local do disparo único.
                Instantiate(laserDoJogador, localDoDisparoUnico.position, localDoDisparoUnico.rotation);
            }
            else // Se o jogador tem o laser duplo, dispara dois lasers.
            {
                // Instancia o laser nas posições à esquerda e à direita.
                Instantiate(laserDoJogador, localDoDisparoDaEsquerda.position, localDoDisparoDaEsquerda.rotation);
                Instantiate(laserDoJogador, localDoDisparoDaDireita.position, localDoDisparoDaDireita.rotation);
            }

            // Toca o som do disparo do laser.
            EfeitosSonoros.instance.somDoLaserDoJogador.Play();
        }
    }

    // Função para desativar o laser duplo quando o tempo expira.
    private void DesativarLaserDuplo()
    {
        temLaserDuplo = false; // Desativa o laser duplo.
        tempoAtualDosLasersDuplos = tempoMaximoDosLasersDuplos; // Restaura o tempo dos lasers duplos.
    }
}
