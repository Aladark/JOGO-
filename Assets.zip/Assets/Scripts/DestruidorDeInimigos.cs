using System.Collections; // Importa a biblioteca para trabalhar com coleções genéricas (não utilizada diretamente neste código, mas pode ser útil em outros casos).
using System.Collections.Generic; // Importa a biblioteca para trabalhar com listas e coleções genéricas (também não usada diretamente aqui).
using UnityEngine; // Importa a biblioteca do Unity, que contém as funções e classes principais para trabalhar com o motor gráfico.

public class DestruidorDeInimigos : MonoBehaviour // Define a classe 'DestruidorDeInimigos', que herda de MonoBehaviour, permitindo que seja um componente de GameObject no Unity.
{
    // Função chamada automaticamente quando um objeto entra em colisão com o trigger (área de detecção) deste objeto.
    void OnTriggerEnter2D(Collider2D other) 
    {
        // Verifica se o objeto que entrou em contato com o trigger tem a tag "Inimigo".
        if(other.gameObject.CompareTag("Inimigo"))
        {
            // Se o objeto for um inimigo, ele será destruído.
            Destroy(other.gameObject);
        }
    }
}
