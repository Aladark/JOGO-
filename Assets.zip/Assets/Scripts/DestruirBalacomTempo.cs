using UnityEngine; // Importa a biblioteca do Unity, que contém as funções e classes principais para trabalhar com o motor gráfico.

public class DestruirBalacomTempo : MonoBehaviour // Define a classe 'DestruirBalacomTempo', que herda de MonoBehaviour, permitindo que seja um componente de GameObject no Unity.
{
    public float tempoDeVida; // Declara uma variável pública para definir o tempo de vida do objeto antes de ser destruído. Pode ser ajustado no Unity Inspector.

    // Start é chamado antes da primeira execução do método Update, logo após o MonoBehaviour ser criado.
    void Start()
    {
        // Chama a função Destroy e passa 'this.gameObject' (o próprio objeto) e o tempo de vida para destruir o objeto após o tempo especificado.
        Destroy(this.gameObject, tempoDeVida);
    }

    // Update é chamado uma vez por quadro.
    void Update()
    {
        // Não há necessidade de lógica no Update para esse script, pois a destruição já está sendo gerenciada no método Start.
    }
}