using System.Collections; // Importa a biblioteca para trabalhar com coleções genéricas (não utilizada diretamente neste código, mas pode ser útil em outros casos).
using System.Collections.Generic; // Importa a biblioteca para trabalhar com listas e coleções genéricas (também não usada diretamente aqui).
using UnityEngine; // Importa a biblioteca do Unity, que contém as funções e classes principais para trabalhar com o motor gráfico.

public class DestruirComOTempo : MonoBehaviour // Define a classe 'DestruirComOTempo', que herda de MonoBehaviour, permitindo que seja um componente de GameObject no Unity.
{
    public float tempoDeVida; // Declara uma variável pública para definir o tempo de vida do objeto. Esse valor pode ser ajustado no Unity Inspector.

    // Start é chamado antes da primeira execução do método Update, logo após o MonoBehaviour ser criado.
    void Start()
    {
        // Chama a função Destroy para destruir o objeto após o tempo especificado.
        // 'this.gameObject' refere-se ao objeto ao qual este script está anexado.
        // 'tempoDeVida' é o número de segundos que o objeto ficará ativo antes de ser destruído.
        Destroy(this.gameObject, tempoDeVida);
    }

    // Update é chamado uma vez por quadro. 
    // No entanto, este método não é necessário para esse script, pois a destruição do objeto já está sendo tratada no método Start.
    void Update()
    {
        // Sem lógica adicional necessária neste caso, o objeto será destruído no método Start.
    }
}
