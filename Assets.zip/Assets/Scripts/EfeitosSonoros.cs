using System.Collections; // Importa a biblioteca para trabalhar com coleções genéricas (não utilizada diretamente neste código, mas pode ser útil em outros casos).
using System.Collections.Generic; // Importa a biblioteca para trabalhar com listas e coleções genéricas (também não usada diretamente aqui).
using UnityEngine; // Importa a biblioteca do Unity, que contém as funções e classes principais para trabalhar com o motor gráfico.

public class EfeitosSonoros : MonoBehaviour // Define a classe 'EfeitosSonoros', que herda de MonoBehaviour, permitindo que seja um componente de GameObject no Unity.
{
    public static EfeitosSonoros instance; // Declara uma variável estática que armazenará a instância única desta classe. Útil para um padrão de design Singleton.

    // Declaração de variáveis públicas para armazenar as fontes de áudio (AudioSource) para diferentes efeitos sonoros.
    public AudioSource somDaExplosao; // Som da explosão.
    public AudioSource somDoLaserDoJogador; // Som do laser disparado pelo jogador.
    public AudioSource somDeImpacto; // Som do impacto (pode ser de colisão com inimigos, etc.).

    // Método Awake é chamado quando o script é carregado, antes de Start e Update.
    void Awake()
    {
        // Atribui a instância atual da classe EfeitosSonoros à variável estática 'instance'.
        // Isso cria uma referência global que pode ser acessada de qualquer parte do código.
        instance = this;
    }

    // Start é chamado antes da primeira execução de Update, logo após o MonoBehaviour ser criado.
    void Start()
    {
        // Não há lógica aqui, mas poderia ser usado para inicializações que não precisam acontecer em Awake.
    }

    // Update é chamado uma vez por quadro.
    void Update()
    {
        // Este método não está sendo utilizado aqui, mas poderia ser usado para atualizar efeitos ou verificar entradas.
    }
}
