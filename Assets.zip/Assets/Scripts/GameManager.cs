using System.Collections; // Importa a biblioteca para trabalhar com coleções genéricas (não utilizada diretamente neste código, mas pode ser útil em outros casos).
using System.Collections.Generic; // Importa a biblioteca para trabalhar com listas e coleções genéricas (também não usada diretamente aqui).
using UnityEngine; // Importa a biblioteca do Unity, que contém as funções e classes principais para trabalhar com o motor gráfico.
using UnityEngine.UI; // Importa a biblioteca do Unity para trabalhar com elementos de interface de usuário (UI), como Text, Button, etc.

public class GameManager : MonoBehaviour // Define a classe 'GameManager', que é responsável por gerenciar o estado do jogo.
{
    public static GameManager instance; // Variável estática que armazena a única instância da classe GameManager, seguindo o padrão Singleton.

    // Variáveis públicas para gerenciar áudio e interface do jogo
    public AudioSource musicaDoJogo; // Fonte de áudio para a música do jogo.
    public AudioSource musicaDeGameOver; // Fonte de áudio para a música de game over.

    // Variáveis públicas para controlar o texto de pontuação e UI do game over
    public Text textoDePontuacaoAtual; // Texto que exibe a pontuação atual no jogo.
    public GameObject painelDeGameOver; // Painel de Game Over que será exibido quando o jogo terminar.
    public Text textoDePontuacaoFinal; // Texto que exibe a pontuação final na tela de game over.
    public Text textoDeHighScore; // Texto que exibe o highscore (pontuação mais alta) armazenado.

    public int pontuacaoAtual; // Variável que armazena a pontuação atual do jogador.

    // O método Awake é chamado quando o script é carregado. Ele é útil para inicializações antes do Start.
    void Awake()
    {
        instance = this; // Atribui a instância atual da classe GameManager à variável estática 'instance'.
    }

    // Start é chamado uma vez antes do primeiro quadro. Inicializa o jogo e configura a pontuação.
    void Start()
    {
        Time.timeScale = 1f; // Garante que o tempo do jogo esteja em tempo real (1f significa velocidade normal do tempo).
        musicaDoJogo.Play(); // Inicia a música do jogo.

        pontuacaoAtual = 0; // Reseta a pontuação do jogador para 0.
        textoDePontuacaoAtual.text = "PONTUAÇÃO: " + pontuacaoAtual; // Atualiza o texto de pontuação atual na interface do usuário.
    }

    // Update é chamado uma vez por quadro, mas não é utilizado aqui.
    void Update()
    {
        // Se fosse necessário atualizar algo constantemente no jogo (como animar objetos ou controlar entradas), faria sentido usar aqui.
    }

    // Função chamada para aumentar a pontuação do jogador.
    public void AumentarPontuacao(int pontosParaGanhar)
    {
        pontuacaoAtual += pontosParaGanhar; // Aumenta a pontuação atual do jogador com a quantidade recebida.
        textoDePontuacaoAtual.text = "PONTUAÇÃO: " + pontuacaoAtual; // Atualiza o texto na UI com a nova pontuação.
    }

    // Função chamada quando o jogo termina (Game Over).
    public void GameOver()
    {
        Time.timeScale = 0f; // Pausa o jogo, fazendo o tempo do jogo parar (o jogo ficará congelado).
        musicaDoJogo.Stop(); // Para a música do jogo.
        musicaDeGameOver.Play(); // Toca a música de Game Over.

        painelDeGameOver.SetActive(true); // Ativa o painel de Game Over na interface do usuário.
        textoDePontuacaoFinal.text = "PONTUAÇÃO: " + pontuacaoAtual; // Exibe a pontuação final no painel de Game Over.

        // Verifica se a pontuação atual é maior que a pontuação mais alta salva (HighScore).
        if (pontuacaoAtual > PlayerPrefs.GetInt("HighScore"))
        {
            PlayerPrefs.SetInt("HighScore", pontuacaoAtual); // Atualiza o HighScore com a pontuação atual.
        }

        // Atualiza o texto do HighScore na interface do usuário.
        textoDeHighScore.text = "HIGHSCORE: " + PlayerPrefs.GetInt("HighScore");
    }
}
