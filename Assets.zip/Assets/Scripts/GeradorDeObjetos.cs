using System.Collections; // Importa a biblioteca para trabalhar com coleções genéricas (não utilizada diretamente neste código, mas pode ser útil em outros casos).
using System.Collections.Generic; // Importa a biblioteca para trabalhar com listas e coleções genéricas (também não usada diretamente aqui).
using UnityEngine; // Importa a biblioteca do Unity, que contém as funções e classes principais para trabalhar com o motor gráfico.

public class GeradorDeObjetos : MonoBehaviour // Define a classe 'GeradorDeObjetos', responsável por gerar (spawnar) objetos em pontos aleatórios do cenário.
{
    public GameObject[] objetosParaSpawnar; // Array de objetos que podem ser gerados. Os objetos são atribuídos no Unity através do Inspector.
    public Transform[] pontosDeSpawn; // Array de pontos de spawn (Transform), onde os objetos serão instanciados. Os pontos são atribuídos no Unity.

    public float tempoMaximoEntreOsSpawns; // O tempo máximo entre dois spawns consecutivos.
    public float tempoAtualDosSpawns; // O tempo atual que está decorrido desde o último spawn.

    // Start é chamado antes da primeira execução de Update.
    void Start()
    {
        tempoAtualDosSpawns = tempoMaximoEntreOsSpawns; // Inicializa o tempo atual com o valor máximo entre os spawns.
    }

    // Update é chamado uma vez por frame. Ele verifica o tempo e chama o método de spawn quando necessário.
    void Update()
    {
        tempoAtualDosSpawns -= Time.deltaTime; // Diminui o tempo atual (em segundos) a cada quadro.

        if (tempoAtualDosSpawns <= 0) // Se o tempo atual chegou a zero ou passou...
        {
            SpawnarObjeto(); // Chama o método para gerar um objeto.
        }
    }

    // Método que realiza o spawn de um objeto.
    private void SpawnarObjeto()
    {
        // Seleciona um índice aleatório para o objeto a ser gerado.
        int objetoAleatorio = Random.Range(0, objetosParaSpawnar.Length);

        // Seleciona um índice aleatório para o ponto de spawn.
        int pontoAleatorio = Random.Range(0, pontosDeSpawn.Length);

        // Instancia o objeto selecionado no ponto de spawn aleatório, com rotação de -90 graus (no eixo Z).
        Instantiate(objetosParaSpawnar[objetoAleatorio], pontosDeSpawn[pontoAleatorio].position, Quaternion.Euler(0f, 0f, -90f));

        // Reseta o tempo atual para o valor máximo de spawn.
        tempoAtualDosSpawns = tempoMaximoEntreOsSpawns;
    }
}
