using System.Collections; // Importa a biblioteca para trabalhar com coleções e listas.
using System.Collections.Generic; // Importa a biblioteca para trabalhar com listas genéricas.
using UnityEngine; // Importa a biblioteca do Unity para poder acessar as classes e funções do motor gráfico.

public class Inimigos : MonoBehaviour // Define a classe 'Inimigos', que controla o comportamento dos inimigos no jogo.
{
    // Referências para objetos e efeitos específicos do inimigo, que são configuradas no Inspector do Unity.
    public GameObject laserDoInimigo; // Prefab do laser disparado pelo inimigo.
    public Transform localDoDisparo; // Posição de onde o laser será disparado.
    public GameObject itemParaDropar; // Item que o inimigo pode deixar cair ao ser destruído.
    public GameObject efeitoDeExplosao; // Efeito visual de explosão quando o inimigo morre.

    // Variáveis que controlam as propriedades do inimigo.
    public float velocidadeDoInimigo; // Velocidade do inimigo na tela.
    public int vidaMaximaDoInimigo; // Vida máxima do inimigo.
    public int vidaAtualDoInimigo; // Vida atual do inimigo (é descontada conforme o inimigo sofre dano).
    public int pontosParaDar; // Pontos que o jogador ganha ao destruir o inimigo.
    public int chanceParaDropar; // Chance (em porcentagem) de o inimigo dropar um item ao ser destruído.
    public int danoDaNave; // Dano que o inimigo causa quando colide com a nave do jogador.

    // Controle do tempo de disparo do laser do inimigo.
    public float tempoMaximoEntreOsLasers; // Tempo máximo entre cada disparo de laser.
    public float tempoAtualDosLasers; // Tempo atual de disparo de lasers, que é decrementado ao longo do tempo.

    // Flags que controlam o comportamento do inimigo.
    public bool inimigoAtirador; // Define se o inimigo pode atirar lasers.
    public bool inimigoAtivado; // Indica se o inimigo foi ativado e está pronto para agir.

    // Start é chamado antes da primeira execução de Update, ou seja, quando o inimigo é criado no jogo.
    void Start()
    {
        inimigoAtivado = false; // Inicializa o inimigo como desativado.

        vidaAtualDoInimigo = vidaMaximaDoInimigo; // Define a vida inicial do inimigo.
    }

    // Update é chamado uma vez por frame, ou seja, a cada ciclo de atualização do jogo.
    void Update()
    {
        MovimentarInimigo(); // Chama a função que move o inimigo.

        // Se o inimigo pode atirar e está ativado, ele tentará disparar um laser.
        if (inimigoAtirador == true && inimigoAtivado == true)
        {
            AtirarLaser(); // Chama a função para atirar o laser.
        }
    }

    // Função chamada para ativar o inimigo, permitindo que ele se movimente e atire.
    public void AtivarInimigo()
    {
        inimigoAtivado = true; // Marca o inimigo como ativado.
    }

    // Função para movimentar o inimigo para baixo, com base em sua velocidade.
    private void MovimentarInimigo()
    {
        // Movimenta o inimigo para baixo (eixo Y) utilizando 'Translate' e aplicando a velocidade do inimigo.
        transform.Translate(Vector3.down * velocidadeDoInimigo * Time.deltaTime);
    }

    // Função para o inimigo atirar lasers.
    private void AtirarLaser()
    {
        tempoAtualDosLasers -= Time.deltaTime; // Diminui o tempo do disparo de laser com o tempo do frame (time.deltaTime).

        // Se o tempo de disparo for zero ou menor, o inimigo dispara um laser.
        if (tempoAtualDosLasers <= 0)
        {
            // Instancia um laser do inimigo na posição de disparo com uma rotação de 90 graus no eixo Z.
            Instantiate(laserDoInimigo, localDoDisparo.position, Quaternion.Euler(0f, 0f, 90f));
            
            // Reseta o tempo do disparo de laser para o valor máximo.
            tempoAtualDosLasers = tempoMaximoEntreOsLasers;
        }
    }

    // Função chamada quando o inimigo recebe dano, reduzindo sua vida.
    public void MachucarInimigo(int danoParaReceber)
    {
        vidaAtualDoInimigo -= danoParaReceber; // Diminui a vida do inimigo pelo valor de dano recebido.

        // Se a vida do inimigo chegar a zero ou menos, ele é destruído.
        if (vidaAtualDoInimigo <= 0)
        {
            // Aumenta a pontuação do jogador com os pontos que o inimigo oferece.
            GameManager.instance.AumentarPontuacao(pontosParaDar);
            
            // Instancia um efeito de explosão na posição do inimigo.
            Instantiate(efeitoDeExplosao, transform.position, transform.rotation);

            // Reproduz o som da explosão do inimigo.
            EfeitosSonoros.instance.somDaExplosao.Play();

            // Gera um número aleatório para determinar se o inimigo vai dropar um item.
            int numeroAleatorio = Random.Range(0, 100);

            // Se o número aleatório for menor ou igual à chance do drop, o inimigo deixa cair um item.
            if (numeroAleatorio <= chanceParaDropar)
            {
                // Instancia o item para o jogador pegar.
                Instantiate(itemParaDropar, transform.position, Quaternion.Euler(0f, 0f, 0f));
            }

            // Destroi o objeto do inimigo após sua morte.
            Destroy(this.gameObject);
        }
    }

    // Função chamada quando o inimigo colide com outro objeto, como a nave do jogador.
    void OnCollisionEnter2D(Collision2D collisionInfo)
    {
        // Se o inimigo colidir com a nave do jogador (verificado pelo tag "Player").
        if (collisionInfo.gameObject.CompareTag("Player"))
        {
            // Aplica dano ao jogador, chamando o método 'MachucarJogador' da nave.
            collisionInfo.gameObject.GetComponent<VidaDoJogador>().MachucarJogador(danoDaNave);

            // Instancia um efeito de explosão na posição do inimigo.
            Instantiate(efeitoDeExplosao, transform.position, transform.rotation);

            // Reproduz o som da explosão do inimigo.
            EfeitosSonoros.instance.somDaExplosao.Play();

            // Destroi o objeto do inimigo após a colisão com a nave.
            Destroy(this.gameObject);
        }
    }
}
