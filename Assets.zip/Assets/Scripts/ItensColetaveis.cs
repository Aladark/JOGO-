using System.Collections; // Importa a biblioteca para usar coleções como listas.
using System.Collections.Generic; // Importa a biblioteca para trabalhar com listas genéricas.
using UnityEngine; // Importa a biblioteca do Unity para acessar suas funções e componentes.

public class ItensColetaveis : MonoBehaviour // Define a classe que controla os itens que o jogador pode coletar no jogo.
{
    // Variáveis para controlar que tipo de item o objeto representa.
    public bool itemDeEscudo; // Se o item coletado é um item de escudo.
    public bool itemDeLaserDuplo; // Se o item coletado é um item de laser duplo.
    public bool itemDeVida; // Se o item coletado é um item que dá vida ao jogador.

    public int vidaParaDar; // A quantidade de vida que o item de vida irá dar ao jogador.

    // Função chamada quando outro objeto entra em contato com o trigger (colisor) deste objeto.
    void OnTriggerEnter2D(Collider2D other)
    {
        // Verifica se o objeto que entrou em contato tem o tag "Player", ou seja, se é o jogador.
        if (other.gameObject.CompareTag("Player"))
        {
            // Se o item é um item de escudo, ativa o escudo do jogador.
            if (itemDeEscudo == true)
            {
                // Chama a função 'AtivarEscudo' no script 'VidaDoJogador', que provavelmente ativa o escudo do jogador.
                other.gameObject.GetComponent<VidaDoJogador>().AtivarEscudo();
            }

            // Se o item é um item de laser duplo, ativa o laser duplo do jogador.
            if (itemDeLaserDuplo == true)
            {
                // Desativa o laser duplo do jogador (provavelmente para resetar o status).
                other.gameObject.GetComponent<ControleDoJogador>().temLaserDuplo = false;

                // Reseta o tempo para o laser duplo.
                other.gameObject.GetComponent<ControleDoJogador>().tempoAtualDosLasersDuplos = other.gameObject.GetComponent<ControleDoJogador>().tempoMaximoDosLasersDuplos;

                // Ativa o laser duplo do jogador.
                other.gameObject.GetComponent<ControleDoJogador>().temLaserDuplo = true;
            }

            // Se o item é um item de vida, aumenta a vida do jogador.
            if (itemDeVida == true)
            {
                // Chama a função 'GanharVida' no script 'VidaDoJogador' para aumentar a vida do jogador.
                other.gameObject.GetComponent<VidaDoJogador>().GanharVida(vidaParaDar);
            }

            // Após o jogador coletar o item, destrói o objeto (o item é consumido).
            Destroy(this.gameObject);
        }
    }
}
