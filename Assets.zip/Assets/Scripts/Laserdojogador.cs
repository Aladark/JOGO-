using System.Collections; // Importa a biblioteca para usar coleções como listas.
using System.Collections.Generic; // Importa a biblioteca para trabalhar com listas genéricas.
using UnityEngine; // Importa a biblioteca do Unity para acessar suas funções e componentes.

public class LaserDoJogador : MonoBehaviour // Define a classe para o laser disparado pelo jogador.
{
    // Variáveis públicas para configurar o comportamento do laser no Unity Inspector.
    public GameObject impactoDoLaserDoJogador; // Prefab do efeito de impacto do laser.
    public float velocidadeDoLaser; // A velocidade do laser (quão rápido ele se move).
    public int danoParaDar; // O dano que o laser causa ao atingir um inimigo.

    // Start é chamado antes da primeira execução de Update (quando o script é inicializado).
    void Start()
    {
        // Não há nenhum comportamento inicial definido neste caso, então o método está vazio.
    }

    // Update é chamado uma vez por quadro (frame).
    void Update()
    {
        // Chama a função para movimentar o laser a cada quadro.
        MovimentarLaser();
    }

    // Função para movimentar o laser na direção vertical (para cima).
    private void MovimentarLaser()
    {
        // Move o laser para cima (ao longo do eixo Y) com a velocidade definida.
        // 'Time.deltaTime' garante que o movimento seja suave, independentemente da taxa de quadros.
        transform.Translate(Vector3.up * velocidadeDoLaser * Time.deltaTime);
    }

    // Função chamada quando o laser colide com outro objeto (com um Collider2D).
    void OnTriggerEnter2D(Collider2D other)
    {
        // Verifica se o objeto que entrou em contato com o laser tem o tag "Inimigo" (um inimigo).
        if(other.gameObject.CompareTag("Inimigo"))
        {
            // Causa dano ao inimigo chamando a função 'MachucarInimigo' no componente 'Inimigos' do inimigo.
            other.gameObject.GetComponent<Inimigos>().MachucarInimigo(danoParaDar);

            // Instancia o efeito de impacto do laser no local da colisão.
            Instantiate(impactoDoLaserDoJogador, transform.position, transform.rotation);

            // Reproduz o som do impacto do laser.
            EfeitosSonoros.instance.somDeImpacto.Play();

            // Destrói o objeto laser após a colisão (o laser desaparece após atingir o inimigo).
            Destroy(this.gameObject);
        }
    }
}
