using System.Collections; // Importa a biblioteca para usar coleções, como listas.
using System.Collections.Generic; // Importa a biblioteca para trabalhar com listas genéricas.
using UnityEngine; // Importa a biblioteca do Unity, que fornece funções e componentes para desenvolvimento de jogos.

public class MoverParaAEsquerda : MonoBehaviour // Define a classe que controla o movimento de um objeto para a esquerda.
{
    public float velocidadeDoObjeto; // Variável pública para definir a velocidade de movimento do objeto.

    // Start é chamado antes da primeira execução de Update (quando o script é inicializado).
    void Start()
    {
        // Não há nenhum comportamento inicial definido neste caso, então o método está vazio.
    }

    // Update é chamado uma vez por frame (ou quadro), ou seja, a cada atualização do jogo.
    void Update()
    {
        // Chama a função 'MovimentarObjeto' a cada quadro para mover o objeto.
        MovimentarObjeto();
    }

    // Função para mover o objeto para a esquerda (no eixo X negativo).
    private void MovimentarObjeto()
    {
        // 'transform.Translate' move o objeto ao longo de um vetor.
        // Neste caso, o objeto se move para baixo (ao longo do eixo Y) com a velocidade definida.
        // O valor de 'Time.deltaTime' garante que o movimento seja suave, independentemente da taxa de quadros.
        transform.Translate(Vector3.down * velocidadeDoObjeto * Time.deltaTime);
    }
}
