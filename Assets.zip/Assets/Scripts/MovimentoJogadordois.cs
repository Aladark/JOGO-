using UnityEngine;

public class MovimentoJogador2 : MonoBehaviour
{


    public float velocidadedaNave;
    private Vector2 teclasdemovimento;
    public Rigidbody2D rigidbody2Djogador2;
    public GameObject laserdojogador;
    public Transform localDoDisparo2;
    public bool temlaserduplo;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        MovimentarJogador();
        Atirarlaser();
    }


    private void MovimentarJogador(){
        teclasdemovimento=new Vector2(Input.GetAxisRaw("Horizontal2"), Input.GetAxisRaw("Vertical2"));
        rigidbody2Djogador2.linearVelocity=teclasdemovimento.normalized*velocidadedaNave;

    }

    private void Atirarlaser(){
        if (Input.GetButtonDown("Fire1")){
            if (temlaserduplo==false){
                Instantiate(laserdojogador,localDoDisparo2.position, localDoDisparo2.rotation);
            }
        }
    }
}
