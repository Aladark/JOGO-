using UnityEngine;
using System.Collections;
using  System.Collections.Generic;

public class MovimentoNave2 : MonoBehaviour
{
    public float velocidadedaNave;
    private Vector2 teclasdemovimento;
    public Rigidbody2D rigidbody2Djogador1;
    public GameObject laserdojogador;
    public Transform localDoDisparo1;
    public bool temlaserduplo;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        temlaserduplo=false;
    }

    // Update is called once per frame
    void Update()
    {
        MovimentarJogador();
        Atirarlaser();
    }

    private void MovimentarJogador(){
        teclasdemovimento=new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        rigidbody2Djogador1.linearVelocity=teclasdemovimento.normalized*velocidadedaNave;

    }

    private void Atirarlaser(){
        if (Input.GetButtonDown("Jump")){
            if (temlaserduplo==false){
                Instantiate(laserdojogador,localDoDisparo1.position, localDoDisparo1.rotation);
            }
        }
    }


}
