using UnityEngine;
using System.Collections;
using  System.Collections.Generic;

public class VidadoJogador: MonoBehaviour
{
  
   public int VidaMaximaDoJogador;
   public int  VidadoAtualDojogar;
   
   public bool temEscudo;



  
    void Start()
    {
        VidadoAtualDojogar = VidaMaximaDoJogador;
    }
    
  
    void Update()
    {
        
    }


   public void DanoJogador(int DanoParaReceber)
   {
             if(temEscudo == false )
             {
                VidadoAtualDojogar -=  DanoParaReceber; 

                if(VidadoAtualDojogar <=0)
                {
                    Debug.Log("GAME OVER");
                }
             }

    }


}
